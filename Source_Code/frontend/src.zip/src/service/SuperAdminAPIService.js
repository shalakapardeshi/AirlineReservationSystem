import axios from 'axios';
import qs from 'qs';
const SUPERADMIN_API_BASE_URL = 'http://localhost:8080';

class ApiService{
    fetchFeedbackByFlightId(airId) {
        return axios.get(SUPERADMIN_API_BASE_URL + '/superadmin/feedback', { params: { airId : airId } } );
    }
    getRevenueReport(airline,period) {
        return axios.get(SUPERADMIN_API_BASE_URL + '/superadmin/revenue_report'  ,{ params: { airlineName : airline, interval :period }, paramsSerializer: (params) => {
            return qs.stringify(params, { arrayFormat: 'repeat' })
          }, } );
    }
    getTotalBookings(){
        return axios.get(SUPERADMIN_API_BASE_URL + '/superadmin/get_total_bookings');
    }
    getCancelledBookings(){
        return axios.get(SUPERADMIN_API_BASE_URL + '/superadmin/get_cancelled_bookings'); 
    }
    getAirlineRevenue(){
        return axios.get(SUPERADMIN_API_BASE_URL + '/superadmin/get_airline_revenue');
    }
}

export default new ApiService();